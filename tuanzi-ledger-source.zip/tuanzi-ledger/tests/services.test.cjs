const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const ts=require(process.env.TYPESCRIPT_LIB||'typescript');
const root=path.resolve(__dirname,'../entry/src/main/ets');
function compile(name,mocks){
 const source=fs.readFileSync(path.join(root,name+'.ets'),'utf8');
 const code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;
 const m={exports:{}};
 new Function('require','module','exports',code)(key=>{
  if(Object.hasOwn(mocks,key))return mocks[key];
  return compile(path.posix.normalize(path.posix.join(path.posix.dirname(name),key)),mocks);
 },m,m.exports);return m.exports;
}
function updater(){
 const values=new Map(),calls=[];let destroyed=0,fail=false,scheduleCount=0,scheduled=false;
 let version={format:'tuanzi-ledger-update-v1',versionCode:1001001,versionName:'0.2.1',notes:'测试版本',distribution:'usb'};
 let sha='a'.repeat(40);
 const p={get:async(k,d)=>values.has(k)?values.get(k):d,put:async(k,v)=>values.set(k,v),flush:async()=>{}};
 const api=compile('services/Updates',{
  '@kit.ArkData':{preferences:{getPreferences:async()=>p}},
  '@kit.NetworkKit':{http:{RequestMethod:{GET:'GET'},HttpDataType:{STRING:'string'},createHttp:()=>({
   request:async(url,options)=>{calls.push({url,options});if(fail)throw Error('network');return {responseCode:200,result:JSON.stringify(url.includes('raw.githubusercontent.com')?version:[{sha}])};},
   destroy:()=>destroyed++})}},
  '@kit.BackgroundTasksKit':{workScheduler:{NetworkType:{NETWORK_TYPE_ANY:0},getWorkStatus:async()=>{if(!scheduled)throw {code:9700004};},
   startWork:()=>{scheduleCount++;scheduled=true;},stopWork:()=>{scheduled=false;}}}
 });
 return {api,values,calls,setFail:v=>fail=v,setSha:v=>sha=v,setVersion:v=>version=v,
  destroyed:()=>destroyed,scheduleCount:()=>scheduleCount};
}
test('network check sends only fixed GET requests and persists daily result',async()=>{
 const x=updater(),s=await x.api.checkUpdates({});assert.equal(s.error,'');assert.equal(s.lastSuccess,s.lastAttempt);assert.equal(s.hasNewVersion,false);
 assert.equal(x.calls.length,2);assert.equal(x.destroyed(),2);
 for(const {url,options} of x.calls){assert.equal(options.method,'GET');assert.equal(options.extraData,undefined);assert.equal(options.maxLimit,65536);assert.match(url,/^https:\/\/(raw\.githubusercontent\.com|api\.github\.com)\//);}
 await x.api.checkUpdates({});assert.equal(x.calls.length,2);
});
test('offline result preserves last successful version and retries after 1h',async()=>{
 const x=updater();const old=await x.api.checkUpdates({});x.setFail(true);
 const s=await x.api.checkUpdates({},true);assert.match(s.error,/失败/);assert.equal(s.lastSuccess,old.lastSuccess);assert.equal(s.commit,old.commit);
 const count=x.calls.length;await x.api.checkUpdates({});assert.equal(x.calls.length,count);assert.equal(x.destroyed(),3);
});
test('repository changes are distinct from released app versions',async()=>{
 const x=updater();await x.api.checkUpdates({});x.setSha('b'.repeat(40));
 const s=await x.api.checkUpdates({},true);assert.equal(s.sourceChanged,true);assert.equal(s.hasNewVersion,false);
 x.setVersion({format:'tuanzi-ledger-update-v1',versionCode:1001002,versionName:'0.2.2',notes:'新的发布',distribution:'usb'});
 assert.equal((await x.api.checkUpdates({},true)).hasNewVersion,true);
});
test('disabled daily checks skip network; manual checks still work',async()=>{
 const x=updater();await x.api.setDailyChecks({},false);await x.api.checkUpdates({});assert.equal(x.calls.length,0);
 await x.api.checkUpdates({},true);assert.equal(x.calls.length,2);
 await x.api.setDailyChecks({},true);await x.api.scheduleDailyChecks();assert.equal(x.scheduleCount(),1);
});
test('installed upgrades invalidate prior upgrade notice and refresh immediately',async()=>{
 const x=updater();x.values.set('installedVersion',1001000);x.values.set('lastSuccess',Date.now());x.values.set('lastAttempt',Date.now());
 x.values.set('status','old update notice');x.values.set('hasNewVersion',true);
 const cached=await x.api.readUpdates({});assert.equal(cached.hasNewVersion,false);assert.equal(cached.lastAttempt,0);
 const refreshed=await x.api.checkUpdates({});assert.equal(x.calls.length,2);assert.equal(refreshed.hasNewVersion,false);
});
function huawei(response,error){
 const requests=[];
 const api=compile('services/HuaweiLogin',{
  '@kit.AccountKit':{authentication:{HuaweiIDProvider:class{createLoginWithHuaweiIDRequest(){return {}}},AuthenticationController:class{async executeRequest(r){requests.push(r);if(error)throw error;return response(r);}}}},
  '@kit.ArkTS':{util:{generateRandomUUID:()=>crypto.randomUUID(),TextEncoder:class{encodeInto(s){return new TextEncoder().encode(s);}}}},
  '@kit.CryptoArchitectureKit':{cryptoFramework:{createMd:()=>{const hash=crypto.createHash('sha256');return {update:async x=>hash.update(x.data),digest:async()=>({data:new Uint8Array(hash.digest())})};}}}
 });return {api,requests};
}
test('Huawei sign-in binds to SDK state and returns only hashed openID',async()=>{
 const x=huawei(r=>({state:r.state,data:{openID:'synthetic-open-id'}}));
 const key=await x.api.huaweiSubject({});assert.equal(key,crypto.createHash('sha256').update('huawei:synthetic-open-id').digest('hex'));
 assert.equal(x.requests[0].forceLogin,true);assert.equal(x.requests[0].scopes,undefined);assert.equal(x.requests[0].permissions,undefined);
});
test('Huawei mismatched state, missing identity and cancel never produce a session key',async()=>{
 for(const response of [()=>({state:'wrong',data:{openID:'test'}}),r=>({state:r.state}),r=>({state:r.state,data:{openID:''}})]){
  await assert.rejects(huawei(response).api.huaweiSubject({}));
 }
 await assert.rejects(huawei(null,{code:1001502012}).api.huaweiSubject({}),/取消/);
 await assert.rejects(huawei(null,{code:1001502005}).api.huaweiSubject({}),/网络/);
});
