import json
import re
import sqlite3
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT/'entry/src/main/ets/data/LedgerStore.ets').read_text()
SQL = [next(v for v in row if v) for row in re.findall(r'''executeSql\((?:'([^']*)'|"([^"]*)"|`([^`]*)`)''',SOURCE)]
def sql(prefix): return next(v for v in SQL if v.startswith(prefix))
class StoreTests(unittest.TestCase):
    def setUp(self):
        self.db=sqlite3.connect(':memory:')
        self.db.execute(sql('PRAGMA'))
        for item in SQL:
            if item.startswith('CREATE TABLE'): self.db.execute(item)
        for name in ['one','two']:
            self.db.execute('INSERT INTO users (name,salt,hash,rounds) VALUES (?,?,?,?)',[name,'salt','hash',600000])
        for user in [1,2]:
            self.db.execute(sql('INSERT INTO accounts'),[user,'cash','钱包',0])
            self.db.execute(sql('INSERT INTO accounts'),[user,'bank','银行卡',0])
            self.db.execute(sql('INSERT INTO categories'),[user,'food','餐饮','🍓','expense'])
        self.db.commit()
    def tearDown(self): self.db.close()
    def add(self,user=1,id='e',kind='expense',amount=100,cat='food',account='cash',target=None):
        self.db.execute(sql('INSERT INTO entries'),[user,id,kind,amount,cat,account,target,'2026-10-19','备注','2026-10-19T08:00:00Z'])
    def test_same_entry_id_in_two_accounts_is_isolated(self):
        self.add(1);self.add(2)
        self.db.execute(sql('DELETE FROM entries WHERE user_id=? AND id=?'),[1,'e'])
        self.assertEqual(self.db.execute('SELECT user_id FROM entries').fetchall(),[(2,)])
    def test_cannot_reference_another_users_account(self):
        self.db.execute(sql('INSERT INTO accounts'),[2,'private','私有钱包',0])
        with self.assertRaises(sqlite3.IntegrityError):self.add(account='private')
    def test_used_account_and_category_cannot_be_deleted(self):
        self.add()
        for command in ['DELETE FROM accounts WHERE user_id=? AND id=?','DELETE FROM categories WHERE user_id=? AND id=?']:
            with self.assertRaises(sqlite3.IntegrityError):self.db.execute(sql(command),[1,'cash' if 'accounts' in command else 'food'])
    def test_invalid_amounts_and_transfer_shape_rejected(self):
        for value in [0,-1,1.5,10000000000]:
            with self.assertRaises(sqlite3.IntegrityError):self.add(amount=value)
        with self.assertRaises(sqlite3.IntegrityError):self.add(kind='transfer',cat=None,target='cash')
        self.add(kind='transfer',cat=None,target='bank')
    def test_failed_restore_rolls_back_and_other_user_is_untouched(self):
        self.add(1);self.add(2);self.db.commit();self.db.execute('BEGIN')
        try:
            for table in ['entries','budgets','categories','accounts']:self.db.execute(next(v for v in SQL if v=='DELETE FROM '+table+' WHERE user_id=?'),[1])
            self.add(1,account='does-not-exist')
            self.db.commit()
        except sqlite3.IntegrityError:self.db.rollback()
        self.assertEqual(self.db.execute('SELECT user_id,id FROM entries ORDER BY user_id').fetchall(),[(1,'e'),(2,'e')])
    def test_parameter_binding_preserves_apostrophes(self):
        name="小猫'); DROP TABLE accounts;--"
        self.db.execute(sql('INSERT INTO accounts'),[1,'new',name,100])
        self.assertEqual(self.db.execute('SELECT name FROM accounts WHERE id=?',['new']).fetchone()[0],name)
    def test_encryption_requested_and_only_update_network_permission(self):
        self.assertIn('encrypt: true',SOURCE)
        module=json.loads((ROOT/'entry/src/main/module.json5').read_text())['module']
        self.assertEqual([p['name'] for p in module.get('requestPermissions',[])], ['ohos.permission.INTERNET'])
    def test_huawei_identity_is_unique_and_cannot_link_two_books(self):
        command=sql('INSERT INTO identity_links')
        self.db.execute(command,['huawei','a'*64,1])
        with self.assertRaises(sqlite3.IntegrityError):self.db.execute(command,['huawei','a'*64,2])
        with self.assertRaises(sqlite3.IntegrityError):self.db.execute(command,['huawei','b'*64,1])
        with self.assertRaises(sqlite3.IntegrityError):self.db.execute(command,['huawei','c'*64,999])
    def test_restore_does_not_replace_identity_binding(self):
        self.db.execute(sql('INSERT INTO identity_links'),['huawei','a'*64,1])
        for table in ['entries','budgets','categories','accounts']:
            self.db.execute(next(v for v in SQL if v=='DELETE FROM '+table+' WHERE user_id=?'),[1])
        self.assertEqual(self.db.execute('SELECT user_id FROM identity_links WHERE subject=?',['a'*64]).fetchone(),(1,))
    def test_passwords_are_salted_kdf_and_not_in_backups(self):
        auth=(ROOT/'entry/src/main/ets/services/Passwords.ets').read_text()
        self.assertIn('PBKDF2|SHA256',auth);self.assertIn('600000',auth);self.assertIn('generateRandom(16)',auth)
        self.assertNotIn('password TEXT',SOURCE)
if __name__=='__main__':unittest.main()
