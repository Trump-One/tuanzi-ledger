const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const ts = require(process.env.TYPESCRIPT_LIB || 'typescript');
const root = path.resolve(__dirname, '../entry/src/main/ets/core');
const cache = new Map();
function load(name) {
  if (cache.has(name)) return cache.get(name);
  const source = fs.readFileSync(path.join(root, name + '.ets'), 'utf8');
  const code = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText;
  const module = { exports: {} };
  new Function('require', 'module', 'exports', code)(request => load(path.basename(request)), module, module.exports);
  cache.set(name, module.exports); return module.exports;
}
const f = load('Finance'); const b = load('BackupFormat');
const account = (id, opening=0) => ({ id, name:id, opening });
const entry = (id, kind, amount, a='cash', c='food', to='', date='2026-10-19') => ({ id, kind, amount, accountId:a,
  categoryId:c, targetId:to, date, note:'', createdAt:'2026-10-19T08:00:00.000Z' });
const book = () => ({ accounts:[account('cash'),account('bank')], categories:[{id:'food',kind:'expense',name:'餐饮',emoji:'🍓'},
  {id:'salary',kind:'income',name:'工资',emoji:'💼'}], entries:[], budgets:[] });
const backup = book => JSON.stringify({ format:'tuanzi-ledger',version:1,exportedAt:'2026-10-19T08:00:00Z',book });

test('money uses exact integer cents, including decimal traps', () => {
  assert.equal(f.parseAmount('0.29'),29); assert.equal(f.parseAmount('10.01'),1001);
  assert.equal(f.parseAmount('99999999.99'),9999999999); assert.equal(f.money(29),'0.29');
  assert.equal(f.parseAmount('-125.08',true,true),-12508); assert.equal(f.parseAmount('0',false,true),0);
});
test('invalid/oversized/zero transaction amounts rejected', () => {
  for (const value of ['0','-1','.1','1.234','1e3','NaN','Infinity','100000000','1.','']) assert.throws(() => f.parseAmount(value),value);
});
test('validates actual calendar dates including leap years', () => {
  assert.equal(f.validDate('2024-02-29'),true); assert.equal(f.validDate('2026-02-29'),false);
  for(const value of ['2026-04-31','2026-00-10','2026-13-01','2026-01-00','2026-1-1',null]) assert.equal(f.validDate(value),false);
  assert.equal(f.shiftMonth('2026-01',-1),'2025-12'); assert.equal(f.shiftMonth('2026-12',1),'2027-01');
});
test('transfers conserve assets and never inflate income/expense', () => {
  const entries=[entry('t','transfer',3450,'cash','','bank'),entry('i','income',10000,'bank','salary'),entry('e','expense',1200)];
  assert.equal(f.balance(account('cash',5000),entries),350); assert.equal(f.balance(account('bank'),entries),13450);
  assert.deepEqual(f.totals(entries,'2026-10'),{ income:10000,expense:1200,net:8800 });
});
test('month boundaries and category totals use only matching entries', () => {
  const value=book(); value.entries=[entry('1','expense',100),entry('2','expense',250),entry('3','expense',900,'cash','food','','2026-09-30'),entry('4','income',600,'bank','salary')];
  assert.equal(f.categoryTotals(value,'2026-10','expense')[0].total,350);
  const bars=f.monthBars(value.entries,'2026-10'); assert.equal(bars.length,6); assert.equal(bars[4].expense,900); assert.equal(bars[5].expense,350);
});
test('complete backup roundtrip preserves balances and no credentials are exported', () => {
  const value=book(); value.accounts[0].opening=-100; value.entries=[entry('a','expense',123),entry('b','transfer',500,'bank','','cash')];
  value.budgets=[{ month:'2026-10',limit:50000 }]; const raw=b.makeBackup(value); const restored=b.validateBackup(raw).book;
  assert.deepEqual(restored,value); assert.equal(f.balance(restored.accounts[0],restored.entries),277);
  assert.equal(/password|salt|hash|credential/.test(raw),false);
});
test('rejects truncated JSON and unsupported backup versions', () => {
  assert.throws(() => b.validateBackup('{"format":'));
  assert.throws(() => b.validateBackup(JSON.stringify({format:'other',version:1,book:book()})));
  assert.throws(() => b.validateBackup(JSON.stringify({format:'tuanzi-ledger',version:2,book:book()})));
});
test('rejects duplicate IDs and missing account references', () => {
  const value=book(); value.accounts.push(account('cash')); assert.throws(() => b.validateBackup(backup(value)));
  const second=book(); second.entries=[entry('e','expense',100,'missing')]; assert.throws(() => b.validateBackup(backup(second)));
});
test('rejects wrong category kind, same-account transfers and unsafe numeric values', () => {
  for (const item of [entry('e','income',100,'cash','food'),entry('t','transfer',100,'cash','','cash'),entry('e','expense',1.5),entry('e','expense',1e15)]) {
    const value=book(); value.entries=[item]; assert.throws(() => b.validateBackup(backup(value)));
  }
});
test('rejects corrupt or duplicate monthly budgets', () => {
  const value=book(); value.budgets=[{month:'2026-13',limit:100}]; assert.throws(() => b.validateBackup(backup(value)));
  value.budgets=[{month:'2026-10',limit:100},{month:'2026-10',limit:100}]; assert.throws(() => b.validateBackup(backup(value)));
});
test('CSV preserves Chinese, quotes and prevents formula injection', () => {
  const value=book(); value.entries=[entry('e','expense',1250)]; value.entries[0].note='  =HYPERLINK("bad")\n草莓蛋糕';
  const csv=b.bookCsv(value); assert.ok(csv.startsWith('\uFEFF')); assert.match(csv,/12\.50/); assert.ok(csv.includes('草莓蛋糕'));
  assert.ok(csv.includes("'  =HYPERLINK(")); assert.ok(csv.includes('""bad""'));
});

function fileService(initial, cancelled=false) {
  let cursor=0, closed=0, opened=0; const written=[];
  const input=Buffer.from(initial,'utf8');
  const fileIo={ OpenMode:{READ_WRITE:1,CREATE:2,TRUNC:4,READ_ONLY:8},
    openSync(){opened++;cursor=0;return {fd:1};}, statSync(){return {size:input.length};},
    readSync(fd, buffer, options={}) {
      cursor+=options.offset||0;
      const n=Math.min(buffer.byteLength,4093,input.length-cursor);
      new Uint8Array(buffer).set(input.subarray(cursor,cursor+n));cursor+=n;return n;
    },
    writeSync(fd, buffer){const bytes=new Uint8Array(buffer);const n=Math.min(7,bytes.length);written.push(Buffer.from(bytes.slice(0,n)));return n;},
    closeSync(){closed++;}
  };
  class Picker {async select(){return cancelled?[]:['fixture.json'];} async save(){return cancelled?[]:['fixture.json'];}}
  const native={picker:{DocumentViewPicker:Picker,DocumentSaveOptions:class{},DocumentSelectOptions:class{}},fileIo};
  const util={TextEncoder:class{encodeInto(text){return new TextEncoder().encode(text);}},
    TextDecoder:class{constructor(enc,opts){this.decoder=new TextDecoder(enc,opts);}decodeToString(value){return this.decoder.decode(value);}}};
  const source=fs.readFileSync(path.resolve(root,'../services/BackupFiles.ets'),'utf8');
  const code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;
  const module={exports:{}};
  new Function('require','module','exports',code)(request=>request==='@kit.CoreFileKit'?native:request==='@kit.ArkTS'?{util}:request==='@kit.AbilityKit'?{}:b,module,module.exports);
  return {service:module.exports,result:()=>Buffer.concat(written).toString('utf8'),closed:()=>closed,opened:()=>opened};
}
test('native file adapter handles multi-chunk and partial UTF-8 reads',async()=>{
  const value=book();for(let i=0;i<300;i++){const e=entry('e'+i,'expense',i+1);e.note='草莓蛋糕🍓'.repeat(20);value.entries.push(e);}
  const raw=backup(value);assert.ok(Buffer.byteLength(raw)>65536);
  const io=fileService(raw);const restored=await io.service.importBook({});assert.deepEqual(restored.book,value);assert.equal(io.closed(),1);
});
test('native file adapter handles partial writes without losing bytes',async()=>{
  const value=book();const e=entry('e','expense',1234);e.note='中文🍓';value.entries=[e];
  const io=fileService('');assert.equal(await io.service.exportBook({},value,false),true);
  assert.deepEqual(b.validateBackup(io.result()).book,value);assert.equal(io.closed(),1);
});
test('cancelling file pickers leaves files untouched',async()=>{
  const io=fileService('',true);assert.equal(await io.service.exportBook({},book(),false),false);
  assert.equal(await io.service.importBook({}),undefined);assert.equal(io.opened(),0);
});

const update = load('UpdatePolicy');
const published = (code=1001001) => ({format:'tuanzi-ledger-update-v1', versionCode:code, versionName:'0.2.1',notes:'更新说明',distribution:'usb'});
test('updates compare integer version codes and reject untrusted manifest shapes',()=>{
  assert.match(update.versionStatus(update.parsePublishedVersion(JSON.stringify(published()))),/当前发布版本/);
  assert.match(update.versionStatus(published(1001002)),/有新版/);
  assert.match(update.versionStatus(published(1000000)),/高于/);
  for(const x of [null,{}, {...published(),versionCode:1.5},{...published(),versionCode:'1001002'},
    {...published(),distribution:'shell'},{...published(),notes:'x'.repeat(4001)},{...published(),versionName:'<script>'}]) {
    assert.throws(()=>update.parsePublishedVersion(JSON.stringify(x)));
  }
  assert.throws(()=>update.parsePublishedVersion(' '.repeat(65537)));
});
test('daily checks throttle success for 24h and failures for 1h; clock rollback recovers',()=>{
  const t=100000000;
  assert.equal(update.checkDue(t,0,0),true);
  assert.equal(update.checkDue(t+86399999,t,t),false);
  assert.equal(update.checkDue(t+86400000,t,t),true);
  assert.equal(update.checkDue(t+3599999,t,0),false);
  assert.equal(update.checkDue(t+3600000,t,0),true);
  assert.equal(update.checkDue(t-1,t,t),true);
});
test('repository commit accepts only one genuine SHA-1; no arbitrary links or code executed',()=>{
  assert.equal(update.parseRepositoryCommit(JSON.stringify([{sha:'a'.repeat(40)}])),'a'.repeat(40));
  for(const x of [null,[],[{}],[{sha:'file:///private'}],[{sha:'a'.repeat(39)}],[{sha:'a'.repeat(40)},{sha:'b'.repeat(40)}]]) {
    assert.throws(()=>update.parseRepositoryCommit(JSON.stringify(x)));
  }
});
